<h1>Hungary</h1>

https://en.wikipedia.org/wiki/List_of_television_stations_in_Hungary

<h2>National</h2>

| #   | Channel        | Link  | Logo | EPG id|
|:---:|:--------------:|:-----:|:----:|:-----:|
| 2   | M1 Hiradó Ⓨ    | [>](https://www.youtube.com/@M1-Hirado/live) | <img height="20" src="https://i.imgur.com/neddXUd.png" /> |
| 4   | M4 Sport Ⓖ     | [>](http://141.94.193.53:80/M4_Sport_HD/index.m3u8) | <img height="20" src="https://nb1.hu/uploads/news/3/31023.jpg" /> | M4Sport.hu |
| 9   | M1 Ⓖ           | [>](http://141.94.193.53:80/M1_HD/index.m3u8) | <img height="20" src="https://i.imgur.com/neddXUd.png" /> | M1.hu |
| 10  | M2 / Petőfi TV Ⓖ | [>](http://141.94.193.53:80/M2_HD/index.m3u8) | <img height="20" src="https://i.imgur.com/CzaDhmA.png" /> | M2.hu |
| 11  | M5 Hungary Ⓖ   | [>](http://141.94.193.53:80/M5_HD/index.m3u8) | <img height="20" src="https://i.imgur.com/qLQz2V6.png" /> | M5.hu |
| 12  | Duna TV Ⓖ      | [>](http://141.94.193.53:80/Duna_HD/index.m3u8) | <img height="20" src="https://i.imgur.com/b4RXacY.png" /> | DunaTV.hu |

<h2>Commercial</h2>

| #   | Channel        | Link  | Logo | EPG id|
|:---:|:--------------:|:-----:|:----:|:-----:|
| 4   | Hír TV         | [>](https://video11.videa.hu/static/live/8.3754346.2530409.1.0.1.1/index.m3u8) | <img height="20" src="https://upload.wikimedia.org/wikipedia/commons/thumb/e/e6/Hirtvujlogo05.jpg/250px-Hirtvujlogo05.jpg" /> | HirTV.hu |
| 7   | ErdélyTV Ⓨ     | [>](https://www.youtube.com/channel/UCS5t4xWMT6lIZ9tcPROUd5A/live) | <img height="20" src="http://kommunikacio.ro/wp-content/uploads/2017/10/erdelytv.png" /> |
| 13  | RTL Klub       | [>](http://141.94.193.53:80/RTL_HD/index.m3u8) | <img height="20" src="https://i.imgur.com/ruRshE1.png" /> | RTLKlub.hu |
| 14  | TV2            | [>](http://141.94.193.53:80/TV2_HD/index.m3u8) | <img height="20" src="https://nlc.p3k.hu/uploads/2021/09/tv2-logo.jpg" /> | TV2.hu |
| 15  | ATV            | [>](http://141.94.193.53:80/ATV_HD/index.m3u8) | <img height="20" src="https://upload.wikimedia.org/wikipedia/commons/thumb/7/7a/Atv_logo_2018.png/250px-Atv_logo_2018.png" /> | ATV.hu |
| 16  | TV4            | [>](http://141.94.193.53:80/TV4_HD/index.m3u8) | | TV4.hu |

<h2>Entertainment</h2>

| #   | Channel        | Link  | Logo | EPG id|
|:---:|:--------------:|:-----:|:----:|:-----:|
| 1   | Cool           | [>](http://141.94.193.53:80/Cool_HD/index.m3u8) | | Cool.hu |
| 2   | Spektrum Ⓖ     | [>](http://141.94.193.53:80/Spektrum_HD/index.m3u8) | | Spektrum.hu |
| 3   | Spektrum Home Ⓖ | [>](http://141.94.193.53:80/Spektrum_Home_HD/index.m3u8) | <img height="20" src="https://upload.wikimedia.org/wikipedia/commons/2/2d/Spektrum-home.png" /> | SpektrumHome.hu |
| 4   | Galaxy4 Ⓖ      | [>](http://141.94.193.53:80/Galaxy4_HD/index.m3u8) | | Galaxy4.hu |
| 5   | DTV Ⓖ          | [>](https://cloudfront44.lexanetwork.com:1344/relay44_1/livestream002.sdp/playlist.m3u8) | <img height="20" src="https://i.imgur.com/YSpqmSO.png" /> | DTV.hu |
| 6   | Sport1 Ⓖ       | [>](http://141.94.193.53:80/Sport_1_HD/index.m3u8) | | Sport1.hu |
| 7   | Sport2 Ⓖ       | [>](http://141.94.193.53:80/Sport_2_HD/index.m3u8) | | Sport2.hu |
| 8   | FEM3 (TV2 Klub) | [>](http://88.212.15.17/live/test_fem3_atktv/playlist.m3u8) | <img height="20" src="https://i.imgur.com/AF4Sz8Z.png" /> | FEM3.hu |
| 9   | Viasat 6       | [>](http://88.212.15.17/live/viasat6/index.m3u8) | <img height="20" src="https://i.imgur.com/kypSbFX.png" /> | Viasat6.hu |

<h2>Religion</h2>

| #   | Channel        | Link  | Logo | EPG id|
|:---:|:--------------:|:-----:|:----:|:-----:|
| 1   | EWTN TV        | [>](https://hls.iptvservice.eu/hls/ewtn-hd.m3u8) | <img height="20" src="https://katolikus.tv/wp-content/themes/bonum/img/ewtn-badge.jpg" /> | BonumTV.hu |
| 2   | Apostol TV     | [>](https://live.apostoltv.hu/live/playlist.m3u8) | <img height="20" src="https://www.apostoltv.hu/images/header-logo.png" /> | ApostolTV.hu |

<h2>Music</h2>

| #   | Channel        | Link  | Logo | EPG id|
|:---:|:--------------:|:-----:|:----:|:-----:|
| 1   | Oxygen Music   | [>](https://oxygenmusic.hu:2443/hls/oxygenmusic.m3u8) | | |
| 2   | Dance TV       | [>](https://m1b2.worldcast.tv/dancetelevisionone/2/dancetelevisionone.m3u8) | | |
| 3   | DikhTv Ⓨ       | [>](https://www.youtube.com/c/DikhTvGipsyTv/live) | <img height="20" src="https://upload.wikimedia.org/wikipedia/commons/3/34/Dikhtv.png" /> | DikhTV.hu |

<h2>Radio</h2>

| #   | Channel        | Link  | Logo | EPG id|
|:---:|:--------------:|:-----:|:----:|:-----:|
| 1   | Kossuth Rádió  | [>](https://budapest-cache-1.antik.sk/live/kossuth_radio/index.m3u8) | | KossuthRadio.hu |
| 2   | Petőfi Rádió   | [>](https://budapest-cache-1.antik.sk/live/petofi_radio/index.m3u8) | | PetofiRadio.hu |
| 3   | Bartók Rádió   | [>](https://budapest-cache-1.antik.sk/live/bartok_radio/index.m3u8) | | BartokRadio.hu |
| 4   | Dankó Rádió    | [>](https://icast.connectmedia.hu/4747/mr7.aac) | | DankoRadio.hu |
| 5   | Rádió1         | [>](https://budapest-cache-1.antik.sk/live/radio_1/index.m3u8) | | |
| 6   | Retró Rádió    | [>](https://budapest-cache-1.antik.sk/live/retro/index.m3u8) | | |
| 7   | 90.9 Jazzy FM  | [>](https://budapest-cache-1.antik.sk/live/jazzy/index.m3u8) | | |
| 8   | Juventus Rádió | [>](https://budapest-cache-1.antik.sk/live/juventus/index.m3u8) | | |
| 9   | Hír FM         | [>](https://budapest-cache-1.antik.sk/live/hir_rm/index.m3u8) | | |
| 10  | Spirit FM      | [>](https://budapest-cache-1.antik.sk/live/spirit_fm/index.m3u8) | | |
| 11  | Sláger FM      | [>](https://budapest-cache-1.antik.sk/live/slager/index.m3u8) | | |

<h2>Series</h2>

| #   | Channel        | Link  | Logo | EPG id|
|:---:|:--------------:|:-----:|:----:|:-----:|
| 1   | Film+          | [>](http://141.94.193.53:80/Film+_HD/index.m3u8) | | Film+.hu |
| 2   | Izaura TV Ⓖ    | [>](http://141.94.193.53:80/Izaura_TV_HD/index.m3u8) | <img height="20" src="https://upload.wikimedia.org/wikipedia/commons/thumb/f/fa/Izaura_TV_logo.svg/250px-Izaura_TV_logo.svg.png" /> | IzauraTV.hu |
| 3   | Film4 Ⓖ        | [>](http://141.94.193.53:80/Film4_HD/index.m3u8) | | Film4.hu |
| 4   | Mozi+ Ⓖ        | [>](http://141.94.193.53:80/Mozi+_HD/index.m3u8) | | MoziPlus.hu |
| 5   | AMC Ⓖ          | [>](http://141.94.193.53:80/AMC_HD/index.m3u8) | | AMC.hu |
| 6   | TV Paprika Ⓖ   | [>](http://141.94.193.53:80/TV_Paprika_HD/index.m3u8) | | TVPaprika.hu |

<h2>News</h2>

| #   | Channel        | Link  | Logo | EPG id|
|:---:|:--------------:|:-----:|:----:|:-----:|
| 1   | Euronews Hungarian | [>](https://cdn-euronews.akamaized.net/live/eds/euronews-hu/25075/index.m3u8) | <img height="20" src="https://upload.wikimedia.org/wikipedia/commons/7/7e/Euronews._2016_logo.png" /> | EuronewsHungarian.fr |
| 2   | Parlamenti közvetítés | [>](https://plenaris.parlament.hu:446/edgelive/smil:mkogyplen.smil/playlist.m3u8) |
| 3   | Parlamenti TAB közvetítés | [>](https://tab.parlament.hu:446/edgelive/smil:mkogytab.smil/playlist.m3u8) |

<h2>Regional</h2>

| #   | Channel        | Link  | Logo | EPG id |
|:---:|:--------------:|:-----:|:----:|:------:|
| 1   | Balaton TV     | [>](https://stream.iptvservice.eu/hls/balatontv.m3u8) | <img height="20" src="https://i.imgur.com/ip8L5Vt.jpg" /> | BalatonTV.hu |
| 2   | Komlos TV      | [>](https://stream.streaming4u.hu/KomlosTV/tracks-v1a1/mono.m3u8) | <img height="20" src="https://i.imgur.com/MDYb5yz.png" /> | KomlosTV.hu |
| 3   | Ózdi Városi TV | [>](http://stream.nmih.hu:7980/live.m3u8) | <img height="20" src="https://i.imgur.com/5cOpdRp.jpg" /> | OzdiVarosiTV.hu |
| 4   | TV7 Békéscsaba | [>](https://stream.y5.hu/stream/stream_bekescsaba/stream.m3u8) | <img height="20" src="https://i.imgur.com/G9Ib5K3.png" /> |
| 5   | 16TV           | [>](https://cloudfront44.lexanetwork.com:1344/freerelay/16tv.sdp/playlist.m3u8) | <img height="20" src="https://i.imgur.com/7ZPYJJ0.jpg" /> |
| 6   | CityTV (Belváros Lipótváros) | [>](https://citytv.hu/playlist.m3u8) | <img height="20" src="https://citytv.hu/wp-content/uploads/2023/12/cropped-citytv.png" /> |
| 7   | FehérvárTV     | [>](https://cloudfront44.lexanetwork.com:1344/relay44_1/HDE046.sdp/playlist.m3u8) | <img height="20" src="https://www.fehervartv.hu/css/img/icon-1-2.png" /> |
| 8   | AlföldTV       | [x](https://cloudfront41.lexanetwork.com:1344/relay01/livestream006.sdp/playlist.m3u8) | <img height="20" src="http://www.dealood.com/content/uploads/images/March2019/5c9721a07ea87-images-large.png" /> |
| 9   | Gyöngyös TV    | [>](https://cloudfront44.lexanetwork.com:1344/relay44_1/HDE043.sdp/playlist.m3u8) | <img height="20" src="https://i.imgur.com/RHgaPCk.png" /> | GyongyosiTV.hu |
| 10  | Halom TV       | [>](rtmp://212.92.13.108/live/livestream1) | <img height="20" src="https://www.halomtv.hu/sites/all/themes/gfx_zen/logo.png" /> |
| 11  | Kapos TV       | [>](https://cloudfront44.lexanetwork.com:1344/relay01/broadcast004.sdp/playlist.m3u8) | <img height="20" src="https://kapos.hu/static/keptar/13/b/9490.jpg" /> | KaposTV.hu |
| 12  | Kecskemét TV   | [>](http://rtmp1.40e.hu:8000/live/ktv.m3u8) | <img height="20" src="https://kecskemetitv.hu/templates/kecskemetitv/img/ktv_logo.png" /> | KecskemetiTV.hu |
| 13  | Lóverseny közvetítés | [x](https://cloudfront41.lexanetwork.com:1344/xrelay/loverseny2.sdp/playlist.m3u8) | <img height="20" src="https://kincsempark.hu/wp-content/uploads/2016/11/fejlec_logo_f-1.png" /> |
| 14  | Zalaegerszeg TV | [>](https://cloudfront44.lexanetwork.com:1344/freerelay/zegtv.sdp/playlist.m3u8) | <img height="20" src="https://zegtv.hu/wp-content/themes/assembly/images/zegtv-logo.png" /> | ZalaegerszegiTV.hu |
| 15  | Zugló TV       | [x](https://cloudfront44.lexanetwork.com:1344/freerelay/zuglotv.sdp/playlist.m3u8) | <img height="20" src="http://zuglotv.hu/wp-content/themes/ztv/uploads/ztv_logo1.jpg" /> |
| 17  | Bajai TV       | [x](https://cloudfront41.lexanetwork.com:1344/relay01/livestream002.sdp/playlist.m3u8) | <img height="20" src="https://i.imgur.com/cyReGWh.png" /> | BajaiTV.hu |
| 18  | Vásárhelyi Televízió | [>](https://stream.vasarhelyitelevizio.hu/stream/stream.m3u8) | <img height="20" src="https://i.imgur.com/WOEqdmx.png" /> | VasarhelyiTelevizio.hu |
| 19  | TV Eger        | [>](http://stream.tveger.hu:8010/live.m3u8) | <img height="20" src="https://i.imgur.com/GUVW073.png" /> | TVEger.hu |
| 20  | Oroszlányi Városi Televízió | [>](https://cloudfront44.lexanetwork.com:1344/relay01/broadcast002.sdp/playlist.m3u8) | <img height="20" src="https://i.imgur.com/P0fxUH5.png" /> | OroszlanyiVarosiTelevizio.hu |
| 21  | Berente TV    | [>](https://stream.streaming4u.hu/BerenteTV/index.m3u8) | | |
| 22  | Budapest Európa TV | [>](https://cloudfront44.lexanetwork.com:1344/freerelay/bpetv.sdp/playlist.m3u8) | | |
| 23  | Héviz TV      | [>](https://cloudfront44.lexanetwork.com:1344/relay03/livestream003.sdp/playlist.m3u8) | | |
| 24  | Jászsági Térségi TV | [>](https://cloudfront44.lexanetwork.com:1344/relay01/broadcast007.sdp/playlist.m3u8) | | |
| 25  | Kanizsa TV    | [>](https://cloudfront44.lexanetwork.com:1344/freerelay/kanizsavtv.sdp/playlist.m3u8) | | |
| 26  | Líceum TV     | [>](http://193.225.32.62:8890/live.m3u8) | | |
| 27  | Pannon RTV    | [>](https://stream2.nmih.hu:4102/live.m3u8) | <img height="20" src="https://i.imgur.com/iD5tCjX.png" /> |
| 28  | Tisza TV      | [x](https://live.tiszatv.hu:443/tmp_hls/stream/index.m3u8) | <img height="20" src="https://www.tiszatv.hu/style/tiszatv_logo.png" /> |
| 29  | Hegyvidék TV (Buda TV) | [>](http://budatv.streaming.aiproduction.hu/playlist.m3u) | <img height="20" src="https://hegyvidektv.hu/wp-content/uploads/2025/05/BUDATV_logo_picon.png" /> |
| 30  | ES TV (Esztergom) | [>](https://cloudfront44.lexanetwork.com:1344/relay44_1/HDE040.sdp/playlist.m3u8) | | EsztergomTV.hu |
| 31  | Komáromi Televízió | [>](https://cloudfront44.lexanetwork.com:1344/relay01/HDE017.sdp/playlist.m3u8) | | KomaromiTelevizio.hu |


<h2>Invalid</h2>

| #   | Channel        | Link  | Logo | EPG id|
|:---:|:--------------:|:-----:|:----:|:-----:|
| 1   | M3             | [x](https://onlinestream.live/play.m3u8?id=5931&ch=1&ext=.m3u8) | <img height="20" src="https://onlinestream.live/logos/5931.png" /> | M3.hu |
| 2   | Duna World / M4+ Sport | [x](http://88.212.15.19/live/duna_world_hun/index.m3u8) | <img height="20" src="https://i.imgur.com/DciAdFF.png" /> | DunaWorld.hu |
| 3   | MUSICPlus      | [x](http://s02.diazol.hu:10192/stream.m3u8) | | |
| 4   | Budakalász     | [x](https://stream.streaming4u.hu/TVBudakalasz/tracks-v1a1/mono.m3u8) | <img height="20" src="https://i.imgur.com/MGkvVQg.png" /> |
| 5   | VTV Füzesabony | [x](https://stream.unrealhosting.hu:443/hls/ftv/live.m3u8) | <img height="20" src="https://i.imgur.com/7ZPYJJ0.jpg" /> | VTVFuzesabony.hu |
| 7   | Miskolc TV     | [x](https://video.mhzrt.hu/live/mitv/playlist.m3u8) | <img height="20" src="https://i.imgur.com/IoiNus2.png" /> | MiskolcTV.hu |
| 8   | Hatoscsatorna  | [x](https://hatoscsatorna.hu:8082/Hatoscsatorna/livestream/playlist.m3u8) | <img height="20" src="https://i.imgur.com/vraAfd7.png" /> | Hatoscsatorna.hu |
| 9   | Putnok Városi TV | [>](http://91.147.248.75:5080/LiveApp/streams/nvUds5LHykQyOVXZ1706907141950.m3u8) | <img height="20" src="https://i.imgur.com/eKXPBFb.png" /> | PVTV.hu |

