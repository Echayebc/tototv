<h1>Czech Republic</h1>

| # | Channel | Link | Logo | EPG id |
|:-:|:-------:|:----:|:----:|:------:|
| 5 | ČT :D | [>](https://sktv.mxnticek.eu/new/stream.php?ch=CT_D) | <img height="20" src="https://raw.githubusercontent.com/tv-logo/tv-logos/main/countries/czech-republic/ct-d-cz.png"/> | CTDecko.cz |
| 7 | ČT sport Plus | [>](https://sktv.mxnticek.eu/new/stream.php?ch=%C4%8CT%20sport%20Plus) | <img height="20" src="https://raw.githubusercontent.com/tv-logo/tv-logos/main/countries/czech-republic/ct-sport-cz.png"/> |  |
| 8 | TV Nova Ⓢ | [>](https://sktv.mxnticek.eu/new/stream.php?ch=Nova) | <img height="20" src="https://raw.githubusercontent.com/tv-logo/tv-logos/main/countries/czech-republic/nova-cz.png"/> | tvnova.cz |
| 9 | Nova Cinema | [>](https://sktv.mxnticek.eu/new/stream.php?ch=NovaCinema) | <img height="20" src="https://raw.githubusercontent.com/tv-logo/tv-logos/main/countries/czech-republic/nova-cinema-cz.png"/> | NovaCinema.cz |
| 10 | Nova Action | [>](https://sktv.mxnticek.eu/new/stream.php?ch=NovaAction) | <img height="20" src="https://raw.githubusercontent.com/tv-logo/tv-logos/main/countries/czech-republic/nova-action-cz.png"/> | NovaAction.cz |
| 11 | Nova Fun | [>](https://sktv.mxnticek.eu/new/stream.php?ch=NovaFun) | <img height="20" src="https://raw.githubusercontent.com/tv-logo/tv-logos/main/countries/czech-republic/nova-fun-cz.png"/> | NovaFun.cz |
| 12 | Nova Gold | [>](https://sktv.mxnticek.eu/new/stream.php?ch=NovaGold) | <img height="20" src="https://raw.githubusercontent.com/tv-logo/tv-logos/main/countries/czech-republic/nova-gold-cz.png"/> | NovaGold.cz |
| 13 | Nova Lady | [>](https://sktv.mxnticek.eu/new/stream.php?ch=NovaLady) | <img height="20" src="https://raw.githubusercontent.com/tv-logo/tv-logos/main/countries/czech-republic/nova-lady-cz.png"/> | NovaLady.cz |
| 14 | TN Live | [>](https://sktv.mxnticek.eu/new/stream.php?ch=Nova%20TN%20Live) | <img height="20" src="https://raw.githubusercontent.com/tv-logo/tv-logos/main/countries/czech-republic/nova-cz.png"/> |  |
| 16 | CNN Prima News | [>](https://sktv.mxnticek.eu/new/stream.php?ch=PrimaNews) | <img height="20" src="https://raw.githubusercontent.com/tv-logo/tv-logos/main/countries/czech-republic/cnn-prima-news-cz.png"/> | CNNPrimaNews.cz |
| 20 | Prima Krimi | [>](https://sktv.mxnticek.eu/new/stream.php?ch=PrimaKrimi) | <img height="20" src="https://raw.githubusercontent.com/tv-logo/tv-logos/main/countries/czech-republic/prima-krimi-cz.png"/> | PrimaKrimi.cz |
| 21 | Prima MAX | [>](https://sktv.mxnticek.eu/new/stream.php?ch=PrimaMax) | <img height="20" src="https://raw.githubusercontent.com/tv-logo/tv-logos/main/countries/czech-republic/prima-max-cz.png"/> | PrimaMax.cz |
| 24 | JOJ Family Ⓢ | [>](https://sktv.mxnticek.eu/new/stream.php?ch=JOJ%20Family) | <img height="20" src="https://raw.githubusercontent.com/tv-logo/tv-logos/main/countries/czech-republic/joj-family-cz.png"/> | JojFamily.sk |
| 25 | JOJ Cinema | [>](https://sktv.mxnticek.eu/new/stream.php?ch=JOJ%20Cinema) | <img height="20" src="https://raw.githubusercontent.com/tv-logo/tv-logos/main/countries/czech-republic/joj-cinema-cz.png"/> | JojCinema.cz |
| 26 | CS Film | [>](https://sktv.mxnticek.eu/new/stream.php?ch=CS%20Film) | <img height="20" src="https://raw.githubusercontent.com/tv-logo/tv-logos/main/countries/slovakia/cs-film-sk.png"/> | CSFilm.cz |
| 27 | CS History | [>](https://sktv.mxnticek.eu/new/stream.php?ch=CS%20History) | <img height="20" src="https://raw.githubusercontent.com/tv-logo/tv-logos/main/countries/czech-republic/cs-history-cz.png"/> | CSHistory.cz |
| 28 | CS Mystery | [>](https://sktv.mxnticek.eu/new/stream.php?ch=CS%20Mystery) | <img height="20" src="https://raw.githubusercontent.com/tv-logo/tv-logos/main/countries/czech-republic/cs-mystery-cz.png"/> | CSMystery.cz |
| 29 | Óčko Ⓢ | [>](https://ocko-live.ssl.cdn.cra.cz/channels/ocko/playlist.m3u8) | <img height="20" src="https://raw.githubusercontent.com/tv-logo/tv-logos/main/countries/czech-republic/ocko-cz.png"/> | Ocko.cz |
| 30 | Óčko Star Ⓢ | [>](https://ocko-live.ssl.cdn.cra.cz/channels/ocko_gold/playlist.m3u8) | <img height="20" src="https://raw.githubusercontent.com/tv-logo/tv-logos/main/countries/czech-republic/ocko-star-cz.png"/> | OckoStar.cz |
| 31 | Óčko Expres Ⓢ | [>](https://ocko-live.ssl.cdn.cra.cz/channels/ocko_expres/playlist.m3u8) | <img height="20" src="https://raw.githubusercontent.com/tv-logo/tv-logos/main/countries/czech-republic/ocko-expres-cz.png"/> | OckoExpres.cz |
| 32 | Šlágr Originál Ⓢ | [>](https://stream-13.mazana.tv/slagroriginal.m3u8s) | <img height="20" src="https://raw.githubusercontent.com/tv-logo/tv-logos/main/countries/czech-republic/slagr-original-cz.png"/> | SlagrOriginal.cz |
| 33 | Šlágr Muzika Ⓢ | [>](https://stream-23.mazana.tv/slagrmuzika.m3u8s) | <img height="20" src="https://raw.githubusercontent.com/tv-logo/tv-logos/main/countries/czech-republic/slagr-muzika-cz.png"/> | SlagrMuzika.cz |
| 34 | Šlágr Premium Ⓢ | [>](https://stream-15.mazana.tv/slagrpremium.m3u) | <img height="20" src="https://raw.githubusercontent.com/tv-logo/tv-logos/main/countries/czech-republic/slagr-premium-cz.png"/> | SlagrPremium.cz |
| 35 | Retro Music TV Ⓢ | [>](https://stream.mediawork.cz/retrotv/smil:retrotv2.smil/playlist.m3u8) | <img height="20" src="https://raw.githubusercontent.com/tv-logo/tv-logos/main/countries/czech-republic/retro-cz.png"/> | RetroMusicTV.cz |
| 36 | Praha TV | [>](https://1977134029.rsc.cdn77.org/1977134029/index.m3u8) | <img height="20" src="https://raw.githubusercontent.com/tv-logo/tv-logos/main/countries/czech-republic/praha-tv-cz.png"/> | PrahaTV.cz |
| 37 | Východoceská TV | [>](https://stream.polar.cz/vctv/vctvlive-1/playlist.m3u8) | <img height="20" src="https://raw.githubusercontent.com/tv-logo/tv-logos/main/countries/czech-republic/tv-v1-cz.png"/> | V1.cz |
| 38 | UTV | [>](https://vysilani.zaktv.cz/broadcast/hls/utv/index.m3u8) | <img height="20" src="https://imgur.com/ulfeIwM.png"/> | utv.cz |

<h2>Invalid</h2>

| #   | Channel        | Link  | Logo | EPG id |
|:---:|:--------------:|:-----:|:----:|:------:|
| 1  | ČT1 | [x](http://88.212.15.19/live/test_ct1_25p/playlist.m3u8) | <img height="20" src="https://raw.githubusercontent.com/tv-logo/tv-logos/main/countries/czech-republic/ct1-cz.png"/> | CT1.cz |
| 2  | ČT2 | [x](http://88.212.15.19/live/test_ct2_25p/playlist.m3u8) | <img height="20" src="https://raw.githubusercontent.com/tv-logo/tv-logos/main/countries/czech-republic/ct2-cz.png"/> | CT2.cz |
| 3  | ČT24 | [x](http://88.212.15.19/live/test_ct24_hevc/playlist.m3u8) | <img height="20" src="https://raw.githubusercontent.com/tv-logo/tv-logos/main/countries/czech-republic/ct24-cz.png"/> | CT24.cz |
| 4  | ČT sport | [x](http://88.212.15.19/live/test_ctsport_25p/playlist.m3u8) | <img height="20" src="https://raw.githubusercontent.com/tv-logo/tv-logos/main/countries/czech-republic/ct-sport-cz.png"/> | CTSport.cz |
| 5  | ČT art | [x](http://88.212.15.19/live/ct_art_avc_25p/playlist.m3u8) | <img height="20" src="https://raw.githubusercontent.com/tv-logo/tv-logos/main/countries/czech-republic/ct-art-cz.png"/> | CTart.cz |
| 6  | Prima | [x](http://88.212.15.19/live/prima_avc_25p/playlist.m3u8) | <img height="20" src="https://raw.githubusercontent.com/tv-logo/tv-logos/main/countries/czech-republic/prima-cz.png"/> | Prima.cz |
| 7  | Prima Zoom | [x](http://88.212.15.19/live/prima_zoom_avc_25p/playlist.m3u8) | <img height="20" src="https://raw.githubusercontent.com/tv-logo/tv-logos/main/countries/czech-republic/prima-zoom-cz.png"/> | PrimaZoom.cz |
| 8  | Prima Love | [x](http://88.212.15.19/live/prima_love_cz_avc/index.m3u8) | <img height="20" src="https://raw.githubusercontent.com/tv-logo/tv-logos/main/countries/czech-republic/prima-love-cz.png"/> | PrimaLove.cz |
| 9  | Prima STAR | [x](http://88.212.15.19/live/test_prima_star_hevc_25p/playlist.m3u8) | <img height="20" src="https://raw.githubusercontent.com/tv-logo/tv-logos/main/countries/czech-republic/prima-star-cz.png"/> | PrimaStar.cz |
| 10  | Prima Cool | [x](http://88.212.15.19/live/prima_cool_cz_avc/index.m3u8) | <img height="20" src="https://raw.githubusercontent.com/tv-logo/tv-logos/main/countries/czech-republic/prima-cool-cz.png"/> | PrimaCool.cz |
| 11  | Prima Show | [x](http://88.212.15.19/live/test_prima_show_hevc_25p/playlist.m3u8) | <img height="20" src="https://raw.githubusercontent.com/tv-logo/tv-logos/main/countries/czech-republic/prima-show-cz.png"/> | PrimaShow.cz |
